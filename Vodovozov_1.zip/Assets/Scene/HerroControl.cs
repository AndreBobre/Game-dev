﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HerroControl : MonoBehaviour {

    public float Speed = 1;
    Rigidbody2D R2D;
    SpriteRenderer Sr;

	// Use this for initialization
	void Start () {
        R2D = this.GetComponent<Rigidbody2D>();
        Sr = GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () { }

    void FixedUpdate()
    {
        float value = Input.GetAxis("Horizontal");

        if (Mathf.Abs(value) > 0)
        {
            Vector2 vel = R2D.velocity;
            vel.x = value * Speed;
            R2D.velocity = vel;
        }
        if (value < 0) Sr.flipX = true;
        else if (value > 0) Sr.flipX = false;
    }

}
