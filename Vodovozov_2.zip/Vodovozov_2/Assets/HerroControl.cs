﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HerroControl : MonoBehaviour
{
    public float speed = 1;
    public float maxJumpTime = 2f;
    public float jumpSpeed = 2f;

    Rigidbody2D r2d;
    SpriteRenderer sr;
    bool isGrounded = false;
    bool jumpActive = false;
    float jumpTime = 0f;

    private Animator animator;

	// Use this for initialization
	void Start ()
    {
        r2d = this.GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        LevelController.current.SetStartPosition(transform.position);
	}
	
	// Update is called once per frame
	void Update () { }

    void FixedUpdate()
    {
        // If the player has made the rabbit jump.
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            this.jumpActive = true;
        }

        // If the rabbit is in flight.
        if (this.jumpActive)
        {
            // If the player keeps holding Jump key.
            if (Input.GetButton("Jump"))
            {
                this.jumpTime += Time.deltaTime;
                if (this.jumpTime < this.maxJumpTime)
                {
                    Vector2 vel = r2d.velocity;
                    vel.y = jumpSpeed * (1.0f - jumpTime / maxJumpTime);
                    r2d.velocity = vel;
                }
            }
            // If the player stop holding Jump key.
            else
            {
                this.jumpActive = false;
                this.jumpTime = 0;
            }
        }

        // If the rabbit moves right or left.
        float value = Input.GetAxis("Horizontal");
        if (Mathf.Abs(value) > 0)
        {
            if (this.jumpTime == 0)
            {
                SetMoveAnimation();
            }
            Vector2 vel = r2d.velocity;
            vel.x = value * speed;
            r2d.velocity = vel;
        }
        else if (this.jumpTime == 0)
        {
            SetIdleAnimation();
        }
        if (value < 0) sr.flipX = true;
        else if (value > 0) sr.flipX = false;

        // Check if the rabbit stays on yhe ground.
        CheckIfGrounded();
        // Change animation for jump if needed.
        SetJumpAnimation();
    }

    private void CheckIfGrounded()
    {
        Vector3 from = transform.position + Vector3.up * 0.3f;
        Vector3 to = transform.position + Vector3.down * 0.1f;
        int layerId = 1 << LayerMask.NameToLayer("Ground");

        RaycastHit2D hit = Physics2D.Linecast(from, to, layerId);

        if (hit)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        Debug.DrawLine(from, to, Color.red);
    }

    private void SetIdleAnimation()
    {
        animator.SetBool("idle", true);
        animator.SetBool("run", false);
        animator.SetBool("jump", false);
    }

    private void SetMoveAnimation()
    {
        animator.SetBool("idle", false);
        animator.SetBool("run", true);
    }

    private void SetJumpAnimation()
    {
        if (isGrounded)
        {
            animator.SetBool("jump", false);
        }
        else
        {
            animator.SetBool("idle", false);
            animator.SetBool("run", false);
            animator.SetBool("jump", true);
        }
    }
}